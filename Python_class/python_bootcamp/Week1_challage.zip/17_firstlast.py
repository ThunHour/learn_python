userInput = input("Input a string: ")

if len(userInput) >0:

    firstChar = userInput[0]
    lastChar = userInput[-1]
    print(f"First Character: {firstChar}")
    print(f"First Character: {lastChar}")



else:
    print("The string is empty.")
