print("**Hello World! Welcome to KIT Python Bootcamp 2020**")
