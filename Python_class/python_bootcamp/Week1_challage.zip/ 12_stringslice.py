userInput = input("Input a text: ")

if len(userInput)> 0:

    middle = len(userInput) // 2

    fistHalf = userInput[:middle]
    secondHalf = userInput[middle:]

    print(f"First half of the text: {fistHalf}")
    print(f"Second half of the text: {secondHalf}")
else:
    print("The string is empty.")
