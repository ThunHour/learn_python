userInput = input("Input a string")

if len(userInput) == 0:
    print("The string is empty.")

else:
    print(userInput.lower())
