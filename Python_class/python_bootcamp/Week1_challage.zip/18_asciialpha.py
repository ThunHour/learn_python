userInput = input("Input a string: ")

if len(userInput)>0:
    for i in userInput:

        print(f'{i} :',ord(i))

else:
    print("The string is empty.")
