newString = ''

userInput = input("Input a string: ")

for char in userInput:

    if char.isupper():

        change = char.lower()
        newString += change

    else:
        change = char.upper()
        newString += change

print(newString)

