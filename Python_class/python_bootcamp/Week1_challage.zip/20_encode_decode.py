again = True

decode = ""
while again == True:
    print("Press 1 to encode")
    print("Press 2 to decode")
    chooseNumber = input()

    if chooseNumber == "1":
        print("Enter the string to decode: ")
        userInput = input("")
        lowerCase = userInput.lower()
        letter = "abcdefghijklmnopqrstuvwxyz"

        for char in lowerCase:
            decode += letter[(letter.find(char)+13)%26]
        print(decode.upper())

        print("Do you want to continue? [Y/N]")
        answer = input()
        if answer == "N":
            break
        else:
            continue

    elif chooseNumber == "2":
        print("Enter the string to decode: ")
        userInput = input("")

        lowerCase = userInput.lower()
        letter = "abcdefghijklmnopqrstuvwxyz"
        decode = ""

        for char in lowerCase:
            decode += letter[(letter.find(char)-13)%26]
        print(decode.upper())

        print("Do you want to continue? [Y/N]")
        answer = input()
        if answer == "N":
            break
        else:
            continue
