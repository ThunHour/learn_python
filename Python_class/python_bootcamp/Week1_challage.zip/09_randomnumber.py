from random import randrange
print(f'Random number is : {randrange(5,10)}')
