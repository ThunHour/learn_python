userInput = input("Enter a string: ")

if len(userInput) > 0:

    print(len(userInput))

else:

    print("The string is empty")
