userInput = input("Please input your name: ")

print(f'Greetings. {userInput} and welcome to the Python Bootcamp')
